document.addEventListener('DOMContentLoaded', function () {
    const darkModeToggle = document.getElementById('darkModeToggle');
    const body = document.body;
    const content = document.getElementById('content');
    const transcriptDiv = document.getElementById('transcript');

    // Font instillinger 
    let currentFontSize = localStorage.getItem('fontSize') || 16;

    // Default dark mode state
    let isDarkModeEnabled = localStorage.getItem('darkMode') === null ? false : true;

    // Apply initial font size and dark mode state
    content.style.fontSize = currentFontSize + 'px';
    if (isDarkModeEnabled) {
        enableDarkMode();
        darkModeToggle.checked = true;
    }

    // Toggle dark mode
    darkModeToggle.addEventListener('change', function () {
        if (darkModeToggle.checked) {
            enableDarkMode();
        } else {
            disableDarkMode();
        }
    });

    // Skru på dark mode
    function enableDarkMode() {
        body.style.backgroundColor = '#333';
        body.style.color = '#fff';
        content.style.fontSize = currentFontSize + 'px';
        localStorage.setItem('darkMode', 'enabled');
    }

    // Skru av Darkmode
    function disableDarkMode() {
        body.style.backgroundColor = '';
        body.style.color = '';
        content.style.fontSize = currentFontSize + 'px';
        localStorage.setItem('darkMode', null);
    }
});


